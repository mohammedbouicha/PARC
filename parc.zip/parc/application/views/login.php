<div class="sidenav">
         <div class="login-main-text">
            <h2>Application<br> Login Page</h2>
            <p>Login or register from here to access.</p>
         </div>
      </div>
      <div class="main">
         <div class="col-md-6 col-sm-12">
         <?php echo validation_errors(); ?>
         <?php echo form_open('welcome/login'); ?>
            <div class="login-form">
               <form>
                  <div class="form-group">
                     <label>E-mail</label>
                     <input type="email" name="email" value="<?php echo set_value('email'); ?>">
                  </div>
                  <div class="form-group">
                     <label>Password</label>
                     <input type="password" name="password" class="form-control" placeholder="Password">
                  </div>
                  <button type="submit" class="btn btn-success">Login</button>
               </form>
            </div>
            <?php echo form_close(); ?>
<p>Don't have an account? <a href="<?php echo site_url('welcome/register'); ?>">Register here</a></p>

         </div>
      </div>