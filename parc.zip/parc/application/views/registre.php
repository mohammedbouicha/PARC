<div class="sidenav">
         <div class="login-main-text">
            <h2>Application<br> Login Page</h2>
            <p>Login or register from here to access.</p>
         </div>
      </div>
      <div class="main">
         <div class="col-md-6 col-sm-12">
         <?php echo validation_errors(); ?>
         <?php echo form_open('welcome/register'); ?>
            <div class="login-form">
               <form>
                  <div class="form-group">
                     <label>User Name</label>
                     <input type="text" class="form-control" name="username" value="<?php echo set_value('username'); ?>" placeholder="User Name">
                  </div>
                  <div class="form-group">
                     <label>E-mail</label>
                     <input type="email" class="form-control" name="email" value="<?php echo set_value('email'); ?>" placeholder="E-mail">
                  </div>
                  <div class="form-group">
                     <label>Password</label>
                     <input type="password" class="form-control" placeholder="Password">
                  </div>
                  <div class="form-group">
                     <label>Confirme Password</label>
                     <input type="password" class="form-control" placeholder="Confirm_Password">
                  </div>
                  <button type="submit" class="btn btn-secondary">Register</button>
                  
               </form>
            </div>
            <?php echo form_close(); ?>
         </div>
      </div>