<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h2>Welcome, <?php echo $username; ?>!</h2>
    <p><a href="<?php echo site_url('welcome/logout'); ?>">Logout</a></p>
</body>
</html>
