<?php
class User_model extends CI_Model {

    // Register new user
    public function register($data) {
        return $this->db->insert('users', $data);
    }

    // Check if user exists by email
    public function check_email_exists($email) {
        $query = $this->db->get_where('users', array('email' => $email));
        return $query->num_rows() > 0;
    }

    // Check user login credentials
    public function login($email, $password) {
        $query = $this->db->get_where('users', array('email' => $email));
        if ($query->num_rows() == 1) {
            $user = $query->row();
            if (password_verify($password, $user->password)) {
                return $user;
            }
        }
        return false;
    }
}
