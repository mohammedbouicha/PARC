<?php
class Dashboard extends CI_Controller {

    public function index() 
    {
        if (!$this->session->userdata('user_id')) {
            redirect('welcome/login');
        }

        $data['username'] = $this->session->userdata('username');
        $this->load->view('dashboard', $data);
    }
}
