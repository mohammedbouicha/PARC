<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct() 
	{
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('form_validation');
    }

    // Registration form
    public function register() {
        // Set validation rules
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('register');
        } else {
            $password = password_hash($this->input->post('password'), PASSWORD_BCRYPT);
            $user_data = array(
                'username' => $this->input->post('username'),
                'email' => $this->input->post('email'),
                'password' => $password
            );
            if ($this->User_model->register($user_data)) {
                $this->session->set_flashdata('message', 'Registration successful! Please login.');
                redirect('welcome/login');
            }
        }
    }

    // Login form
    public function login() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('login');
        } else {
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $user = $this->User_model->login($email, $password);
            if ($user) {
                $this->session->set_userdata('user_id', $user->id);
                $this->session->set_userdata('username', $user->username);
                redirect('dashboard'); // Redirect to dashboard after successful login
            } else {
                $this->session->set_flashdata('message', 'Invalid login credentials!');
                redirect('welcome/login');
            }
        }
    }

    // Logout function
    public function logout() {
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username');
        redirect('welcome/login');
    }
}




	
	// public function index()
	// {
		
	// 	$this->load->view('include/navbar.php');
	// 	$this->load->view('include/sidebar.php');
	// 	$this->load->view('include/footer.php');
	// 	$this->load->view('include/header.php');
		
	// }

	// public function index()
	// {
	// 	$this->load->view('login.php');
	// 	$this->load->view('include/footer.php');
	// 	$this->load->view('include/header.php');
		
	// }






