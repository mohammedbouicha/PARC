(document).ready(function(){
    $(".hamburger").click(function(){
       $(".wrapper").toggleClass("collapse");
    });
});